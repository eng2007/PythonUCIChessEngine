Delfi 5.4 - 2008/07/24

Chess engine for Winboard/UCI.
For more info: http://www.msbsoftware.it/delfi

Requirements:
Delfi 5.4 requires a CPU with MMX extensions.

Installation:
1) To play with the Winboard version ("Delfi.exe") you need
to download and configure Winboard:
http://www.tim-mann.org/xboard.html
2) To play with a UCI chessboard (Fritz, Arena, Chessbase, etc.)
see your chessboard instructions.

Easy levels:
To set a easy level modify the file Delfi.ini, (standard version
is limited to 1000 ELO or full strength).

Parallel version:
To enable parallel processing on dual core processors set
the option CPU_THREADS in Delfi.ini

Author:
Dr. Fabio Cavicchio.
All right reserved.
